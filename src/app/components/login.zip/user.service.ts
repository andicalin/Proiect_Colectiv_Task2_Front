import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs";
import {UserCredentials} from "../shared/data-type/user-credentials";
import {UserAdmin} from "../shared/data-type/userAdmin";
import {Request} from "../shared/data-type/request";
import {UserRequestFormObject} from "../shared/data-type/userRequestFormObject";
import { User } from '../shared/data-type/User';
import { Notification } from "../shared/data-type/notification";
import {UserChangePassword} from "../shared/data-type/userChangePassword";

let bodyUrl:string="";

let LOGIN:string;
let GET_VACATION_DAYS:string;
let ADD_USER:string;
let GET_REQUESTS:string;
let POST_USER_REQUEST:string;
let PUT_USER_REQUEST:string;
let DELETE_USER_REQUEST:string;
let GET_ALL:string;
let DELETE_USER:string
let UPDATE_USER:string
let GET_ALL_WITH_NO_TEAM:string
let GET_USER_NOTIFICATIONS:string
let READ_NOTIFICATIONS:string
let RESET_PASSWORD:string
let DOWNLOAD_REPORT:string
let GET_TEAM_ID:string
let SEND_TO_HR:string
//const UPLOAD_TO_CLOUD = 'https://gentle-mountain-44660.herokuapp.com/https://9ausqv1gij.execute-api.us-east-1.amazonaws.com/internship-test/pdf'


@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient: HttpClient) {
    if(window.location.host == "localhost:4200"){
      bodyUrl="http://localhost:8090";
    }
    else{
      bodyUrl="http://codebooliesinternshipapp-env.eba-xeauzw2u.us-east-1.elasticbeanstalk.com"
    }
    LOGIN = bodyUrl+"/auth/login";
    GET_VACATION_DAYS = bodyUrl+"/user/get-days-left";
    ADD_USER = bodyUrl+'/user/add'
    GET_REQUESTS = bodyUrl+"/request/get-requests-by-type?type=";
    POST_USER_REQUEST = bodyUrl+"/request/make-new-request";
    PUT_USER_REQUEST = bodyUrl+"/request/update-request";
    DELETE_USER_REQUEST = bodyUrl+"/request/cancel-request/";
    GET_ALL = bodyUrl+'/user/get-all'
    DELETE_USER= bodyUrl+'/user/delete'
    UPDATE_USER=bodyUrl+'/user/update'
    GET_ALL_WITH_NO_TEAM= bodyUrl+'/user/get-all-no-team';
    GET_USER_NOTIFICATIONS = bodyUrl+'/notification/get-notifications';
    READ_NOTIFICATIONS = bodyUrl+'/notification/read-notifications';
    RESET_PASSWORD = bodyUrl+'/user/change-password';
    DOWNLOAD_REPORT = bodyUrl+'/user/generate-report';
    GET_TEAM_ID = bodyUrl+'/user/get-team-id';
    SEND_TO_HR = bodyUrl+'/user/complete-document/';
  }

  public loginUser(userCredentials: UserCredentials): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');
    localStorage.setItem("email", userCredentials.email)

    return this.httpClient.post<any>(LOGIN, userCredentials);
  }


  public getVacationDays(): Observable<JSON>{

    return this.httpClient.get<JSON>(GET_VACATION_DAYS);
  }


  public getTeamId(): Observable<number>
  {
    return this.httpClient.get<number>(GET_TEAM_ID);
  }
  public getHolidayRequestsByType(type: string): Observable<Request[]> {

    return this.httpClient.get<Request[]>(GET_REQUESTS + type);
  }

  public createUser(user: UserAdmin): Observable<UserAdmin>
  {
    console.log(user);
    return this.httpClient.post<UserAdmin>(ADD_USER,user);
  }


  public updateUser(user: UserAdmin): Observable<UserAdmin>
  {

    return this.httpClient.put<UserAdmin>(UPDATE_USER,user);
  }


  public makeUserRequest(requestFormObject: UserRequestFormObject): Observable<Request> {
    return this.httpClient.post<Request>(POST_USER_REQUEST, requestFormObject);
  }

  public updateUserRequest(requestFormObject: UserRequestFormObject): Observable<Request> {

    return this.httpClient.put<Request>(PUT_USER_REQUEST, requestFormObject);
  }

  public cancelUserRequest(holidayId: number): Observable<string> {

    return this.httpClient.delete<string>(DELETE_USER_REQUEST + holidayId);
  }

  public getAllUsers(): Observable<UserAdmin[]> {
    return this.httpClient.get<UserAdmin[]>(GET_ALL);
  }

  public deleteUsers(id: Number): Observable<UserAdmin> {

    //console.log(id);
    let endpoints="/"+id;
    //console.log(DELETE_USER+endpoints);
    return this.httpClient.delete<UserAdmin>(DELETE_USER+endpoints);
  }

  public getAllUsersWithNoTeam() {

    return this.httpClient.get<User[]>(GET_ALL_WITH_NO_TEAM);
  }

  public getUserNotifications(): Observable<Notification[]> {

    return this.httpClient.get<Notification[]>(GET_USER_NOTIFICATIONS);
  }

  public readNotifications(): Observable<string> {

    console.log(READ_NOTIFICATIONS);

    return this.httpClient.put<string>(READ_NOTIFICATIONS, null);
  }

  public changePassword(resetPasswordBody: UserChangePassword): Observable<any>{
    return this.httpClient.patch<UserChangePassword>(RESET_PASSWORD,resetPasswordBody)
  }

  public downloadReport(): Observable<any> {
    return this.httpClient.get(DOWNLOAD_REPORT)
  }

  public sendToHr(holidayId: number): Observable<any> {
    return this.httpClient.get(SEND_TO_HR+holidayId);
  }

  // public uploadToCloud(document:any): Observable<any> {
  //   console.log("Uploading to cloud...")
  //   console.log(document)
  //   return this.httpClient.post(UPLOAD_TO_CLOUD,document)
  // }
}
